var class_d_a_l_1_1_customer =
[
    [ "Customer", "class_d_a_l_1_1_customer.html#a1076d282fdbc0fe003be177c52915d1f", null ],
    [ "contractID", "class_d_a_l_1_1_customer.html#aebe99d900af560a48edbc139e48bb92b", null ],
    [ "customerID", "class_d_a_l_1_1_customer.html#a672f0280c01179c94d9aff712feb96fc", null ],
    [ "customerName", "class_d_a_l_1_1_customer.html#a5bd506e895e60a849c9e7b567c190339", null ],
    [ "CustomerID", "class_d_a_l_1_1_customer.html#aaacaab2a8b8c97a51556f15146229eef", null ],
    [ "CustomerName", "class_d_a_l_1_1_customer.html#ab017bccc652654c43b6f42452346ca93", null ]
];