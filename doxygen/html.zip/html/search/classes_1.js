var searchData=
[
  ['buyer_84',['Buyer',['../class_d_a_l_1_1_buyer.html',1,'DAL']]]
];
