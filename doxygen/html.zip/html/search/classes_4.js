var searchData=
[
  ['logfile_89',['LogFile',['../class_d_a_l_1_1_log_file.html',1,'DAL']]]
];
