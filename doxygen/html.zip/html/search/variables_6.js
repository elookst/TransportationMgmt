var searchData=
[
  ['numberofdays_144',['numberOfDays',['../class_d_a_l_1_1_trip.html#af14bc906a5269d4579336830a413e6ff',1,'DAL::Trip']]],
  ['numofintermediatecities_145',['numOfIntermediateCities',['../class_d_a_l_1_1_trip.html#a6ee42b604450cceb15d9781a3b9f8e9d',1,'DAL::Trip']]]
];
