var namespaces_dup =
[
    [ "DAL", "namespace_d_a_l.html", "namespace_d_a_l" ]
];