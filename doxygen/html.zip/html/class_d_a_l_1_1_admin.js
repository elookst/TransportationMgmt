var class_d_a_l_1_1_admin =
[
    [ "Admin", "class_d_a_l_1_1_admin.html#a60e60120a2aab2ce5bbd3715e5072cda", null ],
    [ "AccessToConfig", "class_d_a_l_1_1_admin.html#aecf3b154fd9df8bd9cfe7fb86ba802a4", null ],
    [ "AlterCarrier", "class_d_a_l_1_1_admin.html#adf3f7ffb1d4075fca71973165a74bbf9", null ],
    [ "AlterRate", "class_d_a_l_1_1_admin.html#ae5b96f90c3d4f6ad5f79917c6c7a6da2", null ],
    [ "AlterRoute", "class_d_a_l_1_1_admin.html#abdaefeadbdef7a6dc92ce1ce5264c321", null ],
    [ "ReviewLog", "class_d_a_l_1_1_admin.html#a5ab2cbfe68d28a478b3bfc76628f3a50", null ],
    [ "adminID", "class_d_a_l_1_1_admin.html#a8384391b72e88a83b36a407e279f3daa", null ],
    [ "adminName", "class_d_a_l_1_1_admin.html#ab3ee69c7f408bf20ce38982c267b0b17", null ],
    [ "rate", "class_d_a_l_1_1_admin.html#a2d6ae34c9211cf8ccbfb1f840c85e693", null ],
    [ "AdminID", "class_d_a_l_1_1_admin.html#aba7a5b37cb43a3b5e1ad0b45bb8d6ad2", null ],
    [ "AdminName", "class_d_a_l_1_1_admin.html#ae0085f4d275c117d09eef11b6c9bbdd1", null ]
];