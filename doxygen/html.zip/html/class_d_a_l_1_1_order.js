var class_d_a_l_1_1_order =
[
    [ "amount", "class_d_a_l_1_1_order.html#a85bfc23ded5aa2707f6f614dfb2a5ace", null ],
    [ "cargoQuantity", "class_d_a_l_1_1_order.html#ae326e3143844e72cca0f2cd92ebbee73", null ],
    [ "cargoType", "class_d_a_l_1_1_order.html#a6eafc44256fd5eb7e36f53d725914424", null ],
    [ "carrier", "class_d_a_l_1_1_order.html#ac5c6d9b7fa691b9b0a34d5d7792237e0", null ],
    [ "CustomerName", "class_d_a_l_1_1_order.html#ae61eee26d36c2ebfa9462cc1a100cfd0", null ],
    [ "departCity", "class_d_a_l_1_1_order.html#a215d0a09b9987617c069abd16d50ae91", null ],
    [ "destCity", "class_d_a_l_1_1_order.html#ae0fa850d21559c29fb9cd34386127beb", null ],
    [ "orderDate", "class_d_a_l_1_1_order.html#a07618c5dc1709f85a2bf2a462d0d3c9b", null ],
    [ "orderID", "class_d_a_l_1_1_order.html#a89e7df7700ba43a89803cfbd6917fdc4", null ]
];