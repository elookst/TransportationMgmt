var searchData=
[
  ['admin_83',['Admin',['../class_d_a_l_1_1_admin.html',1,'DAL']]]
];
