var searchData=
[
  ['adminname_131',['adminName',['../class_d_a_l_1_1_admin.html#ab3ee69c7f408bf20ce38982c267b0b17',1,'DAL::Admin']]]
];
