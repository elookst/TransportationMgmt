var searchData=
[
  ['adminid_155',['AdminID',['../class_d_a_l_1_1_admin.html#aba7a5b37cb43a3b5e1ad0b45bb8d6ad2',1,'DAL::Admin']]],
  ['adminname_156',['AdminName',['../class_d_a_l_1_1_admin.html#ae0085f4d275c117d09eef11b6c9bbdd1',1,'DAL::Admin']]],
  ['amount_157',['amount',['../class_d_a_l_1_1_order.html#a85bfc23ded5aa2707f6f614dfb2a5ace',1,'DAL::Order']]]
];
