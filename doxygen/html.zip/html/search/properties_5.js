var searchData=
[
  ['orderdate_167',['orderDate',['../class_d_a_l_1_1_order.html#a07618c5dc1709f85a2bf2a462d0d3c9b',1,'DAL::Order']]]
];
