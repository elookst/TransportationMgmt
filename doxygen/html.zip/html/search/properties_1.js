var searchData=
[
  ['buyername_158',['buyerName',['../class_d_a_l_1_1_buyer.html#a4302f8dc258394da5464905f685f0a40',1,'DAL::Buyer']]]
];
