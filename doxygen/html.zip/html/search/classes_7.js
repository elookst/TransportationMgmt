var searchData=
[
  ['summaryreport_93',['SummaryReport',['../class_d_a_l_1_1_summary_report.html',1,'DAL']]]
];
