var annotated_dup =
[
    [ "DAL", "namespace_d_a_l.html", [
      [ "Program", "class_d_a_l_1_1_program.html", "class_d_a_l_1_1_program" ],
      [ "Admin", "class_d_a_l_1_1_admin.html", "class_d_a_l_1_1_admin" ],
      [ "Buyer", "class_d_a_l_1_1_buyer.html", "class_d_a_l_1_1_buyer" ],
      [ "Planner", "class_d_a_l_1_1_planner.html", "class_d_a_l_1_1_planner" ],
      [ "Configuration", "class_d_a_l_1_1_configuration.html", "class_d_a_l_1_1_configuration" ],
      [ "LogFile", "class_d_a_l_1_1_log_file.html", "class_d_a_l_1_1_log_file" ],
      [ "Order", "class_d_a_l_1_1_order.html", "class_d_a_l_1_1_order" ],
      [ "Customer", "class_d_a_l_1_1_customer.html", "class_d_a_l_1_1_customer" ],
      [ "Carrier", "class_d_a_l_1_1_carrier.html", "class_d_a_l_1_1_carrier" ],
      [ "Invoice", "class_d_a_l_1_1_invoice.html", "class_d_a_l_1_1_invoice" ],
      [ "Trip", "class_d_a_l_1_1_trip.html", "class_d_a_l_1_1_trip" ],
      [ "SummaryReport", "class_d_a_l_1_1_summary_report.html", "class_d_a_l_1_1_summary_report" ]
    ] ]
];