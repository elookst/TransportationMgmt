var searchData=
[
  ['buyer_103',['Buyer',['../class_d_a_l_1_1_buyer.html#a2f9176d01fad0e2f2a333664b40d6bd4',1,'DAL::Buyer']]]
];
