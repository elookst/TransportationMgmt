var searchData=
[
  ['carrierid_132',['carrierID',['../class_d_a_l_1_1_invoice.html#a1e9c2a809a22a4cd62ead5c8de45864c',1,'DAL::Invoice']]],
  ['contractid_133',['contractID',['../class_d_a_l_1_1_customer.html#aebe99d900af560a48edbc139e48bb92b',1,'DAL::Customer']]],
  ['customerid_134',['customerID',['../class_d_a_l_1_1_invoice.html#a6b8971d79eedb16fb78fd127699b4aa2',1,'DAL::Invoice']]],
  ['customername_135',['customerName',['../class_d_a_l_1_1_customer.html#a5bd506e895e60a849c9e7b567c190339',1,'DAL::Customer']]]
];
