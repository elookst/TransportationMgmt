var searchData=
[
  ['buyer_11',['Buyer',['../class_d_a_l_1_1_buyer.html#a2f9176d01fad0e2f2a333664b40d6bd4',1,'DAL.Buyer.Buyer()'],['../class_d_a_l_1_1_buyer.html',1,'DAL.Buyer']]],
  ['buyername_12',['buyerName',['../class_d_a_l_1_1_buyer.html#a4302f8dc258394da5464905f685f0a40',1,'DAL::Buyer']]]
];
