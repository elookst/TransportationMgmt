var class_d_a_l_1_1_buyer =
[
    [ "Buyer", "class_d_a_l_1_1_buyer.html#a2f9176d01fad0e2f2a333664b40d6bd4", null ],
    [ "AddNewCustomer", "class_d_a_l_1_1_buyer.html#a2fb9c02d4fe9578ca4484c18f1092768", null ],
    [ "AddOrder", "class_d_a_l_1_1_buyer.html#a313ed1e20233492870a1f5a1d1b85831", null ],
    [ "GenerateInvoice", "class_d_a_l_1_1_buyer.html#ad5cb4413e4a28b433e3340389166cfb6", null ],
    [ "RequestContracts", "class_d_a_l_1_1_buyer.html#a7ffb586056eb6ecdfbaf718e750024ef", null ],
    [ "ReviewCompleteOrder", "class_d_a_l_1_1_buyer.html#ae36be063fafbc20c2769ed604343ea4c", null ],
    [ "ReviewCustomer", "class_d_a_l_1_1_buyer.html#a95f7fd452068e08ee4e624d9a8bc8a1b", null ],
    [ "SelectCity", "class_d_a_l_1_1_buyer.html#a17821688c1cda2a86c169cbfd6cdc8ed", null ],
    [ "SendInvoice", "class_d_a_l_1_1_buyer.html#a03d930e5992617be780479b323542cdf", null ],
    [ "SuggestCarrier", "class_d_a_l_1_1_buyer.html#a8cb73720e8b7a751f6ea9abc8cf2e948", null ],
    [ "buyerID", "class_d_a_l_1_1_buyer.html#aba06038a153f8638f2532969cb4b1bd3", null ],
    [ "buyerName", "class_d_a_l_1_1_buyer.html#a4302f8dc258394da5464905f685f0a40", null ]
];