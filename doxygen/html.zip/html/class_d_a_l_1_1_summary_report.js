var class_d_a_l_1_1_summary_report =
[
    [ "GenerateInvoiceReport", "class_d_a_l_1_1_summary_report.html#a31bb52453793bedfffd65e3c08545c2f", null ],
    [ "ReviewCurrentOrders", "class_d_a_l_1_1_summary_report.html#accd56165556a6f5ea2e732ef74045c1f", null ]
];